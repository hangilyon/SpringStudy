package com.care.root.mybatis;

public interface FileMapper {

}
