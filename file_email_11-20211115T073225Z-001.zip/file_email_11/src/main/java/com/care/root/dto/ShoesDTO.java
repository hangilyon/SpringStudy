package com.care.root.dto;


public class ShoesDTO {

}
