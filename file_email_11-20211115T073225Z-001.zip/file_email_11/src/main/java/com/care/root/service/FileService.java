package com.care.root.service;

public interface FileService {

}
